# Lab 0, Your Name
import matplotlib as mpl
mpl.use('Agg')

import sympy as sy
import numpy as np
import matplotlib.pyplot as plt


# Exercise 1
print("Exercise 1:")
# x = np.array([1, 2, -2, 3, 4])
x = np.array([-1, -2, -3, 1, 2, 3])


def f(x):
    y = np.copy(x)
    mask = np.where(y < 0.0) # Or mask = y < 0.0, where is not needed.
    y[mask] = 0.0
    return y


y = f(x)
print("Initial vector  = ", x)
print("Result vector  = ", y)
print("\n")


# Exercise 2
print("Exercise 2:")
t = np.linspace(-1.0, 10.0, 100)
plt.figure(1)
plt.plot(t, t**2-3.0, 'k')
plt.title(r"Plot of $f(x)=t^2-3$")
plt.savefig("figure1.png")
print("done \n\n")

# Exercise 3
print("Exercise 2:")
x = sy.symbols('x')
expr = x/(x**2+2*x+1)
print(sy.integrate(expr, x))
print("done \n\n")

# Exercise 4
print("Exercise 4:")
expr2 = sy.diff(expr, x)
fexpr = sy.lambdify(x, expr2, "numpy")
t = np.linspace(0.0, 1.0, 100)
plt.figure(2)
plt.plot(t, fexpr(t), 'k')
plt.title(r"Plot of derivative of $f(x) = \frac{x}{x^2+2x+1}$")
plt.savefig('figure2.png')
print("done \n\n")
