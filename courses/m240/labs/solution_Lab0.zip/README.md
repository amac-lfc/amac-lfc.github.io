# Lab 0

All the exercises are in **main.py**. To see the result run the following command:
```
python3 main.py
```